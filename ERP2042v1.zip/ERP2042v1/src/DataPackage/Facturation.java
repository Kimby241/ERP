package DataPackage;

import DataPackage.ProcessusComponent;
import java.util.ArrayList;
import java.util.Iterator;

public class Facturation extends ProcessusComponent {
	
    String etat;
	
    public Facturation(String etat){
	this.etat = etat;
    }
	
    public String getEtat() { return etat; }

    public void displayProcessusInfo(){
	System.out.println(getEtat() + "\n");
    }
}
