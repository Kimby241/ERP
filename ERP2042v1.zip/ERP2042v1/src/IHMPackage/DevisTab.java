package IHMPackage;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import javafx.scene.control.Tab;
import javafx.scene.layout.StackPane;
/**
 *
 * @author Kim
 */
public class DevisTab extends Tab{
    StackPane centerDisplayer;
    
    public DevisTab() {
        this.setText("Devis");
        this.setClosable(false);
        loadDisplayer();
        this.setContent(centerDisplayer);
    }
    
    public void loadDisplayer() {
        this.centerDisplayer = new DevisListDisplayerPane();
    }
    
    public void loadAddForm() {
        
    }
    
    public void loadEditForm() {
        
    }
}
