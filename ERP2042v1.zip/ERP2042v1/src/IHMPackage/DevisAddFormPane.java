/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package IHMPackage;

import javafx.scene.layout.StackPane;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TextArea;
/**
 *
 * @author Kim
 */
public class DevisAddFormPane extends StackPane{
    Label titre;
    ComboBox projectsList;
    ComboBox clientsList;
    TextField prospectName;
    TextArea remarque;
}
