package IHMPackage;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Kim
 */
public class FacturesTab extends Tab{
    StackPane centerDisplayer;
    
    public FacturesTab() {
        this.setText("Factures");
        this.setClosable(false);
        loadDisplayer();
        this.setContent(centerDisplayer);
    }
    
    public void loadDisplayer() {
        this.centerDisplayer = new FactureListDisplayerPane();
    }
    
    public void loadAddForm() {
        
    }
    
    public void loadEditForm() {
        
    }
}
